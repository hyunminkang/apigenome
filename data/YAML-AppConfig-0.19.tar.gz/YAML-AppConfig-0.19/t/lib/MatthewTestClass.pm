package MatthewTestClass;

sub LoadFile {
    return {file => shift};
}

sub Load {
    return {string => shift};
}

1;
