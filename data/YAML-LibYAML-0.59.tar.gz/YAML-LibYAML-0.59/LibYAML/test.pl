use Test::More tests => 1;

pass 'Tests for libyaml extension are all defined at the top level';
